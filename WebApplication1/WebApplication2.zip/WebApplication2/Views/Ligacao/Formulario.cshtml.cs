using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Views.Ligacao
{
    public class FormularioModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
