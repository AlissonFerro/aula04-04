using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Views.Livro
{
    public class ListagemModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
