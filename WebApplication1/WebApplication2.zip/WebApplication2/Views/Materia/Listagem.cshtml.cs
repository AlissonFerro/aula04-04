using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Views.Materia
{
    public class ListagemModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
