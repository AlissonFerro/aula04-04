using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Views.Materia
{
    public class ErroModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
