using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApplication2.Views.Materia
{
    public class FormularioExcluirModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
