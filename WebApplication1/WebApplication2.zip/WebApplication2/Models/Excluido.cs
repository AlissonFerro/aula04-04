﻿namespace WebApplication2.Models
{
    public class Excluido : Aluno
    {
        List<Aluno> excluidos = new List<Aluno>();
        
    }
}
